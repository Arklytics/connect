<?php
// Database connection
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'growthlink';

// Create connection
$db = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$db) {
    die('Database connection failed: ' . mysqli_connect_error());
}
?>
