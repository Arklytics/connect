<?php include 'header.php';?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2" style="left: 0; height: 100vh; overflow-y: auto; background-color: #00002E;">
                <?php include 'sidebar.php'; ?>
        </div>

<!-- Main Content -->
        <div class="col-md-9">
            <p>Main Content</p>
        </div>

    </div>
</div>



<?php include 'footer.php';?>


