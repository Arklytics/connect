<div class="text-light" >
  <ul class="list-group list-group-flush">
    <li class="list-group-item text-light shadow rounded mt-2 p-3"><i class="bi bi-house-heart-fill"></i> Dashboard</li>

    <!-- Orders Dropdown -->
    <li class="list-group-item  text-light dropdown-toggle shadow rounded mt-2 p-3" id="ordersDropdown" style="cursor: pointer;">
    <i class="bi bi-bag-heart-fill"></i> Orders
    </li>
    <ul class="list-group collapse  text-light ms-3" id="ordersMenu">
      <li class="list-group-item  text-light">New Order</li>
      <li class="list-group-item  text-light">View Order</li>
    </ul>

    <!-- Templates Dropdown -->
    <li class="list-group-item text-light dropdown-toggle shadow rounded mt-2 p-3" id="templatesDropdown" style="cursor: pointer;">
    <i class="bi bi-list-columns-reverse"></i> Templates
    </li>
    <ul class="list-group collapse  text-light ms-3" id="templatesMenu">
      <li class="list-group-item text-light">New Template</li>
      <li class="list-group-item  text-light">Check Templates</li>
    </ul>

    <li class="list-group-item  text-light shadow rounded mt-2 p-3"><i class="bi bi-whatsapp"></i> Messages</li>

    <!-- Settings Dropdown -->
    <li class="list-group-item  text-light dropdown-toggle shadow rounded mt-2 p-3" id="settingsDropdown" style="cursor: pointer;">
    <i class="bi bi-gear-fill"></i>  Settings
    </li>
    <ul class="list-group collapse  text-light ms-3" id="settingsMenu">
      <li class="list-group-item  text-light">Add Token</li>
    </ul>

    <!-- Reports Dropdown -->
    <li class="list-group-item  text-light dropdown-toggle shadow rounded mt-2 p-3" id="reportsDropdown" style="cursor: pointer;">
    <i class="bi bi-clipboard-data-fill"></i> Reports
    </li>
    <ul class="list-group collapse  text-light ms-3 " id="reportsMenu">
      <li class="list-group-item  text-light shadow rounded mt-2 p-3">Payments</li>
      <li class="list-group-item  text-light shadow rounded mt-2 p-3">Messages</li>
      <li class="list-group-item  text-light shadow rounded mt-2 p-3">Templates</li>
      <li class="list-group-item  text-light shadow rounded mt-2 p-3">Orders</li>
    </ul>

    <li class="list-group-item  text-light shadow rounded mt-2 p-3"><i class="bi bi-x-circle-fill"></i> Logout</li>
  </ul>
</div>

<!-- JavaScript for Dropdowns -->
<script>
  // Toggle function for dropdown menus
  document.getElementById("ordersDropdown").addEventListener("click", function () {
    toggleDropdown("ordersMenu");
  });

  document.getElementById("templatesDropdown").addEventListener("click", function () {
    toggleDropdown("templatesMenu");
  });

  document.getElementById("settingsDropdown").addEventListener("click", function () {
    toggleDropdown("settingsMenu");
  });

  document.getElementById("reportsDropdown").addEventListener("click", function () {
    toggleDropdown("reportsMenu");
  });

  function toggleDropdown(menuId) {
    const menu = document.getElementById(menuId);
    if (menu.classList.contains("collapse")) {
      menu.classList.remove("collapse");
    } else {
      menu.classList.add("collapse");
    }
  }
</script>
